const observer = new MutationObserver(mutations => {
	const topAd = document.querySelector(".adsbyvli");
	const ads = document.querySelectorAll("iframe");

	if (topAd) {
		topAd.parentElement.remove();
	}

	for (let i = 0; i < ads.length; i++) {
		const ad = ads[i];
		if (ad.parentElement.getAttribute("data-ub-carousel")) {
			ad.parentElement.style.display = "none";
			ad.parentElement.remove();
		}
	}
});

observer.observe(document, {
	childList: true,
	subtree: true,
	attributes: true
});